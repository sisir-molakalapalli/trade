/**
 * Unit tests for strategy.js — run with:  npm test   (or: node --test tests/)
 * No network, no dependencies.
 */
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const S = require('../strategy');
const Y = require('../tools/synthetic');

const MIN = 60000;
function newPos(entry = 100, stopPct = 1.0, openedAt = 0) {
  const stop = entry * (1 - stopPct / 100);
  return { entryPriceUSDT: entry, initialStopPrice: stop, sl: stop, openedAt, atrPct: 0.6, ratchetStage: 'INITIAL', tp1Secured: false };
}

// ---------------------------------------------------------------- exits
test('stop fires the moment price touches it — even at a loss', () => {
  const pos = newPos();
  assert.equal(S.managePosition(pos, 99.5, 1 * MIN).action, 'HOLD');
  const r = S.managePosition(pos, 98.99, 2 * MIN);
  assert.equal(r.action, 'EXIT');
  assert.equal(r.reason, 'STOP LOSS');
  assert.equal(r.isLoss, true);
});

test('REGRESSION v4 bug: a trade that was +1R then collapses exits at breakeven, not -3.8%', () => {
  const pos = newPos();
  S.managePosition(pos, 101.05, 5 * MIN);                 // +1.05R -> breakeven armed
  assert.equal(pos.ratchetStage, 'BREAKEVEN');
  assert.ok(pos.sl > 100, 'stop must be above entry');
  // price gaps straight through the stop in one tick (v4 ignored this case)
  const r = S.managePosition(pos, 99.0, 6 * MIN);
  assert.equal(r.action, 'EXIT');
  assert.equal(r.reason, 'BREAKEVEN STOP');
});

test('breakeven stop covers both fees', () => {
  const pos = newPos();
  S.managePosition(pos, 101.2, MIN);
  const pnl = S.netPnl(1, 100, pos.sl);
  assert.ok(pnl > 0, `exit at breakeven stop should be net positive, got ${pnl}`);
});

test('TP1 sells half at +1.5R and locks +0.5R', () => {
  const pos = newPos();
  const r = S.managePosition(pos, 101.55, MIN);
  assert.equal(r.action, 'PARTIAL');
  assert.equal(r.fraction, 0.5);
  assert.ok(pos.tp1Secured);
  assert.ok(pos.sl >= 100.5 - 1e-9, `sl ${pos.sl} should be >= entry + 0.5R`);
});

test('runner trails 1 ATR under the peak after TP1', () => {
  const pos = newPos();
  S.managePosition(pos, 101.6, MIN);                      // TP1
  S.managePosition(pos, 102.5, 2 * MIN);                  // new peak
  const expected = 102.5 * (1 - 0.6 / 100);
  assert.ok(Math.abs(pos.sl - expected) < 1e-9);
  assert.equal(S.managePosition(pos, expected - 0.01, 3 * MIN).reason, 'TRAILING STOP');
});

test('full exit at +3R', () => {
  const pos = newPos();
  S.managePosition(pos, 101.6, MIN);
  const r = S.managePosition(pos, 103.01, 2 * MIN);
  assert.equal(r.action, 'EXIT');
  assert.match(r.reason, /TARGET/);
});

test('time stop closes a trade that goes nowhere for 90 minutes', () => {
  const pos = newPos();
  assert.equal(S.managePosition(pos, 100.1, 89 * MIN).action, 'HOLD');
  const r = S.managePosition(pos, 100.1, 91 * MIN);
  assert.equal(r.action, 'EXIT');
  assert.match(r.reason, /TIME STOP/);
});

test('worst case loss of any v5 trade is bounded by the stop (no -3.8% outcome)', () => {
  // random walk torture test, 1-minute ticks for 4 hours, 500 paths
  let seed = 7;
  const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296 - 0.5; };
  let worst = 0;
  for (let n = 0; n < 500; n++) {
    const pos = newPos(100, 1.2);
    let p = 100;
    for (let m = 1; m <= 240; m++) {
      p *= 1 + rnd() * 0.004;                              // up to ±0.2% per minute
      const r = S.managePosition(pos, p, m * MIN);
      if (r.action === 'EXIT') { worst = Math.min(worst, (p - 100)); break; }
    }
  }
  assert.ok(worst > -1.5, `worst loss ${worst.toFixed(2)}% should stay near the 1.2% stop`);
});

// ---------------------------------------------------------------- entries
test('clean closed-bar breakout in an uptrend is accepted with a bounded stop', () => {
  const r = S.evaluateEntry(Y.cleanBreakoutSetup());
  assert.equal(r.ok, true, r.reason);
  assert.ok(r.stopPct >= S.CONFIG.minStopPct && r.stopPct <= S.CONFIG.maxStopPct);
});

test('an OPEN (unfinished) candle is never used as the trigger', () => {
  const r = S.evaluateEntry(Y.openBarSetup());
  assert.equal(r.ok, false);
});

test('1h downtrend is rejected', () => {
  const r = S.evaluateEntry(Y.downtrendSetup());
  assert.equal(r.ok, false);
  assert.match(r.reason, /EMA/);
});

test('missing data is rejected (fail closed)', () => {
  assert.equal(S.evaluateEntry({ k15: null, k1h: null }).ok, false);
  assert.equal(S.evaluateEntry({ k15: [], k1h: [] }).ok, false);
  assert.equal(S.evaluateBtcRegime(null, null).ok, false);
});

// ---------------------------------------------------------------- sizing
test('position size makes a stop-out cost 0.5% of equity', () => {
  const sig = S.evaluateEntry(Y.cleanBreakoutSetup());
  const plan = S.planEntry(sig, sig.refPrice, 1000, 1000);
  assert.equal(plan.ok, true, plan.reason);
  assert.ok(plan.riskUSDT <= 5.0001, `risk ${plan.riskUSDT} should be <= $5 on $1000`);
  assert.ok(plan.notional <= 150.0001, 'never more than 15% of equity');
});

test('planEntry refuses to chase a price that already ran', () => {
  const sig = S.evaluateEntry(Y.cleanBreakoutSetup());
  const R = sig.refPrice - sig.stopPrice;
  assert.equal(S.planEntry(sig, sig.refPrice + 0.6 * R, 1000, 1000).ok, false);
});

test('netPnl subtracts fees on both sides', () => {
  assert.ok(Math.abs(S.netPnl(1, 100, 100) - (-0.2)) < 1e-9);
});

// ---------------------------------------------------------------- guard
test('daily loss limit pauses trading', () => {
  const now = Date.UTC(2026, 10, 7, 10, 0, 0);
  const trades = [{ id: now - 60000, pair: 'X/USDT', pnlUSDT: -21, type: 'STOP LOSS' }];
  assert.equal(S.portfolioGuard(trades, 1000, now).ok, false);
});

test('3 losses in a row pauses for 2h, then resumes', () => {
  const now = Date.UTC(2026, 10, 7, 10, 0, 0);
  const trades = [1, 2, 3].map((i) => ({ id: now - i * 60000, pair: `C${i}/USDT`, pnlUSDT: -1, type: 'STOP LOSS' }));
  assert.equal(S.portfolioGuard(trades, 1000, now).ok, false);
  assert.equal(S.portfolioGuard(trades, 1000, now + 121 * MIN).ok, true);
});

test('a coin that just lost is in cooldown for 4h', () => {
  const now = Date.now();
  const trades = [{ id: now - 30 * MIN, pair: 'SOL/USDT', pnlUSDT: -0.5 }];
  assert.equal(S.inSymbolCooldown(trades, 'SOL/USDT', now), true);
  assert.equal(S.inSymbolCooldown(trades, 'SOL/USDT', now + 241 * MIN), false);
});
