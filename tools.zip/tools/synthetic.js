/**
 * Synthetic Binance-format klines for offline tests (no network needed).
 * kline = [openTime, open, high, low, close, volume, closeTime, quoteVol, trades, takerBuyBase, takerBuyQuote, 0]
 */
'use strict';

function bar(t, ms, o, h, l, c, v, takerShare = 0.55) {
  return [t, String(o), String(h), String(l), String(c), String(v), t + ms - 1, String(v * c), 100, String(v * takerShare), String(v * c * takerShare), '0'];
}

/** Steady uptrend: n bars, each +stepPct, range ~rangePct. */
function trend(n, intervalMs, startPrice, stepPct, rangePct, startTime, vol = 1000) {
  const out = [];
  let p = startPrice;
  for (let i = 0; i < n; i++) {
    const o = p, c = p * (1 + stepPct / 100);
    const h = Math.max(o, c) * (1 + rangePct / 200), l = Math.min(o, c) * (1 - rangePct / 200);
    out.push(bar(startTime + i * intervalMs, intervalMs, o, h, l, c, vol));
    p = c;
  }
  return out;
}

/**
 * A clean long setup that SHOULD pass evaluateEntry:
 * 1h uptrend; 15m drift up, 8-bar tight base, then a closed high-volume breakout bar.
 * Returns { k15, k1h, now } where `now` is just after the breakout bar closed.
 */
function cleanBreakoutSetup() {
  const M15 = 15 * 60000, H1 = 3600000;
  const now = Date.UTC(2026, 10, 7, 12, 0, 0) + 5000;
  const end = now - 5000;                                          // breakout bar closes here
  const k1h = trend(100, H1, 80, 0.12, 0.8, end - 100 * H1);       // 1h: +0.12%/bar
  const base = Number(k1h[k1h.length - 1][4]);
  // 15m: 91 bars of gentle drift ending at `base`, then 8 bars flat, then breakout
  const startTime = end - 100 * M15;
  const drift = trend(91, M15, base * 0.985, 0.0165, 0.55, startTime);
  const flatP = Number(drift[drift.length - 1][4]);
  const flat = [];
  for (let i = 0; i < 8; i++) {
    const t = startTime + (91 + i) * M15;
    const o = flatP * (1 + (i % 2 ? 0.0005 : -0.0005)), c = flatP * (1 + (i % 2 ? -0.0005 : 0.0005));
    flat.push(bar(t, M15, o, flatP * 1.0025, flatP * 0.9975, c, 1000));
  }
  const bt = startTime + 99 * M15;
  const bo = flatP, bc = flatP * 1.0065;
  const breakout = bar(bt, M15, bo, bc * 1.0005, bo * 0.999, bc, 2600, 0.62);
  const k15 = [...drift, ...flat, breakout];
  return { k15, k1h, now };
}

/** Same setup but the last bar is still OPEN (close time in the future). */
function openBarSetup() {
  const s = cleanBreakoutSetup();
  const k15 = s.k15.map((k) => k.slice());
  k15[k15.length - 1][6] = s.now + 600000;
  return { ...s, k15 };
}

/** 1h downtrend version. */
function downtrendSetup() {
  const s = cleanBreakoutSetup();
  const H1 = 3600000;
  const k1h = trend(100, H1, 120, -0.25, 0.8, s.now - 5000 - 100 * H1);
  return { ...s, k1h };
}

module.exports = { bar, trend, cleanBreakoutSetup, openBarSetup, downtrendSetup };
