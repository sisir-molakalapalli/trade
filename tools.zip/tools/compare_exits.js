/**
 * Monte Carlo: v4.3 exit rules vs v5 exit rules on the SAME random price paths.
 *
 * Random-walk prices have zero edge by construction, so neither rule set can be
 * profitable here. What this shows is the SHAPE of the losses each rule set
 * produces — and that v4.3's rules turn ordinary noise into -3.8% disaster cuts.
 *
 *   node tools/compare_exits.js [paths=3000] [dailyVolPct=4] [edgePctPerHour=0]
 *
 * edgePctPerHour > 0 adds an upward drift for the first EDGE_HOURS (default 2h)
 * after entry, i.e. a momentum entry whose edge fades, like real breakouts.
 * jumpProb adds fat tails: chance per path of one sudden -3% candle (BTC dump,
 * listing news, liquidation cascade) at a random time.
 *
 *   node tools/compare_exits.js 3000 4 0.3 0.15
 */
'use strict';
const S = require('../strategy');

const PATHS = Number(process.argv[2]) || 3000;
const DAILY_VOL = Number(process.argv[3]) || 4;       // % daily vol of a typical alt
const STEP_SEC = 10;
const HORIZON_SEC = 3 * 86400;                         // give every trade 3 days
const STEPS = HORIZON_SEC / STEP_SEC;
const DRIFT = (Number(process.argv[4]) || 0) / 100 / (3600 / STEP_SEC);
const EDGE_STEPS = (Number(process.env.EDGE_HOURS) || 2) * 3600 / STEP_SEC;
const JUMP_PROB = Number(process.argv[5]) || 0;
const sigma = DAILY_VOL / 100 / Math.sqrt(86400 / STEP_SEC);
const FEE = 0.10;                                      // % per side

// deterministic RNG so results are reproducible
let seed = 42;
const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
const gauss = () => { const u = Math.max(rnd(), 1e-12), v = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };

function makePath() {
  const p = new Float64Array(STEPS + 1); p[0] = 1;
  const jumpAt = rnd() < JUMP_PROB ? Math.floor(rnd() * STEPS) : -1;
  for (let i = 1; i <= STEPS; i++) {
    const d = i <= EDGE_STEPS ? DRIFT : 0;
    p[i] = p[i - 1] * Math.exp(d + sigma * gauss() - 0.5 * sigma * sigma) * (i === jumpAt ? 0.97 : 1);
  }
  return p;
}

// ---- v4.3 rules (from server.js runPredictiveSentry, candlestick/order-flow harvests omitted) ----
function runOld(path) {
  const entry = 1, floor = entry * 1.0035;
  let sl = floor, stage = 'INITIAL', peak = entry, tp1 = false, realized = 0, remaining = 1;
  let bag = null;
  for (let i = 1; i <= STEPS; i++) {
    const price = path[i], t = i * STEP_SEC, gain = (price - entry) / entry * 100;
    if (!bag) {
      peak = Math.max(peak, price);
      const peakGain = (peak - entry) / entry * 100;
      if (peakGain >= 0.35 && stage === 'INITIAL') { stage = 'BE'; sl = floor; }
      if (peakGain >= 0.70 && stage !== 'PL' && stage !== 'DT' && stage !== 'RUN') { stage = 'PL'; sl = Math.max(floor, entry * 1.005); }
      if (peakGain >= 1.0 && peakGain < 1.8) { stage = 'DT'; sl = Math.max(floor, sl, peak * 0.9965); }
      if (gain >= 1.8 && !tp1) { tp1 = true; stage = 'RUN'; sl = Math.max(floor, peak * 0.995); realized += 0.5 * gain; remaining = 0.5; }
      // the v4 stop only fires inside the window [floor, sl]
      if (stage !== 'INITIAL' && price <= sl && gain >= 0.35 && price >= floor) return done(realized + remaining * gain, t, 'TRAIL');
      if (t >= 45 * 60 && gain >= 0.35) return done(realized + remaining * gain, t, 'SCRATCH45');
      if (!tp1 && gain < 0.35) {
        let demote = gain <= -2.8;
        if (!demote && t >= 25 * 60 && gain <= -1.5) demote = path[i] < path[Math.max(0, i - 30)];
        if (demote) bag = { movedAt: t, peak: price, armed: false, rsl: 0 };
      }
    } else {
      const hh = (t - bag.movedAt) / 3600;
      const tr = hh >= 3.5 ? 0 : hh >= 1.5 ? 0.0010 : 0.0030;
      const target = entry * (1 + tr);
      bag.peak = Math.max(bag.peak, price);
      const calc = bag.peak * 0.997;
      if (price >= target || calc >= target) bag.armed = true;
      if (bag.armed) bag.rsl = Math.max(bag.rsl, target, calc);
      if (bag.armed && price <= bag.rsl) return done(gain, t, 'BAG_RECOVERED');
      if (gain <= -3.8) return done(gain, t, 'DISASTER');
    }
  }
  return done(realized + remaining * ((path[STEPS] - entry) / entry * 100), HORIZON_SEC, 'STILL_OPEN');
}

// ---- v5 rules (the real managePosition from strategy.js) ----
function runNew(path) {
  const atr = 0.6;                                       // typical 15m ATR% for this vol
  const stopPct = Math.max(atr * S.CONFIG.atrStopMult, S.CONFIG.minStopPct);
  const pos = { entryPriceUSDT: 1, initialStopPrice: 1 - stopPct / 100, sl: 1 - stopPct / 100, openedAt: 0, atrPct: atr };
  let realized = 0, remaining = 1;
  for (let i = 1; i <= STEPS; i++) {
    const price = path[i], t = i * STEP_SEC * 1000;
    const r = S.managePosition(pos, price, t);
    const gain = (price - 1) * 100;
    if (r.action === 'PARTIAL') { realized += r.fraction * gain; remaining -= r.fraction; }
    if (r.action === 'EXIT') return done(realized + remaining * gain, t / 1000, r.reason);
  }
  return done(realized + remaining * ((path[STEPS] - 1) * 100), HORIZON_SEC, 'STILL_OPEN');
}

function done(grossPct, sec, reason) { return { net: grossPct - 2 * FEE, sec, reason }; }

function summarize(name, rs) {
  const wins = rs.filter((r) => r.net > 0), losses = rs.filter((r) => r.net <= 0);
  const avg = (a) => a.length ? a.reduce((s, r) => s + r.net, 0) / a.length : 0;
  const reasons = {};
  rs.forEach((r) => { reasons[r.reason] = (reasons[r.reason] || 0) + 1; });
  const worst = Math.min(...rs.map((r) => r.net));
  const big = rs.filter((r) => r.net <= -3).length;
  console.log(`\n=== ${name} ===`);
  console.log(`win rate            ${(100 * wins.length / rs.length).toFixed(1)}%`);
  console.log(`avg win / avg loss  +${avg(wins).toFixed(2)}% / ${avg(losses).toFixed(2)}%  (net of fees)`);
  console.log(`expectancy / trade  ${avg(rs).toFixed(3)}%`);
  console.log(`worst trade         ${worst.toFixed(2)}%`);
  console.log(`trades losing >=3%  ${(100 * big / rs.length).toFixed(1)}%`);
  console.log(`avg hold            ${(rs.reduce((s, r) => s + r.sec, 0) / rs.length / 3600).toFixed(2)} h`);
  console.log(`exit reasons        ${Object.entries(reasons).map(([k, v]) => `${k}:${v}`).join('  ')}`);
}

const oldR = [], newR = [];
for (let n = 0; n < PATHS; n++) { const p = makePath(); oldR.push(runOld(p)); newR.push(runNew(p)); }
console.log(`${PATHS} paths, ${DAILY_VOL}% daily vol, edge ${(Number(process.argv[4])||0)}%/h for ${EDGE_STEPS*STEP_SEC/3600}h, jump prob ${JUMP_PROB}, fees ${FEE}%/side`);
summarize('v4.3 exits (never close below +0.35%, bag until -3.8%)', oldR);
summarize('v5 exits (real stop, breakeven at 1R, TP1 1.5R, trail, time stop)', newR);
